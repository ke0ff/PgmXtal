Software repo for the si598/ATtiny85 configurable oscillator project.
Joe Haas
11/10/2023
