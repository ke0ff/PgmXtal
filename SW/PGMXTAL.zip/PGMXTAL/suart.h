/*
 * SUART_tx.h
 *
 * header file for bit-bang UART.
 *
 * Modified by Joe Haas, 11/14/2023
 *
 */ 

#ifndef SOFT_UART_H_
	#define SUART_H

	//###############OPTIONS###############
	#ifndef F_CPU
		#define F_CPU 7695360UL // ATTINY-85 default OSC freq
	// system clock divide prescale value (set to 99 for ATTINY-85 factory default setting)
	#endif
								// Set this define to get the desired sysclk frequency
	#define CLKPRSC_DIV	2		// valid values: 1, 2, 4, 8, 16, 32, 64, 128, 256
	///////////////////////////////////////////////////////////////////////////////

	#if CLKPRSC_DIV == 1
		#define	CLKPR_BIT	0
		#define CLKPR_DIV	1UL
	#else
			#if CLKPRSC_DIV == 2
				#define CLKPR_BIT	1
				#define CLKPR_DIV	2UL
			#else
					#if CLKPRSC_DIV == 4
						#define CLKPR_BIT	2
						#define CLKPR_DIV	4UL
					#else
							#if CLKPRSC_DIV == 8
								#define CLKPR_BIT	3
								#define CLKPR_DIV	8UL
							#else
									#if CLKPRSC_DIV == 16
										#define CLKPR_BIT	4
										#define CLKPR_DIV	16UL
									#else
											#if CLKPRSC_DIV == 32
												#define CLKPR_BIT	5
												#define CLKPR_DIV	32UL
											#else
													#if CLKPRSC_DIV == 64
														#define CLKPR_BIT	6
														#define CLKPR_DIV	64UL
													#else
															#if CLKPRSC_DIV == 128
																#define CLKPR_BIT	7
																#define CLKPR_DIV	128UL
															#else
																	#if CLKPRSC_DIV == 256
																		#define CLKPR_BIT	8
																		#define CLKPR_DIV	256UL
																	#else
																		CLKPR_DIV = 8UL
																		CLKPR_BIT = 3
																	#endif
															#endif
													#endif
											#endif
									#endif
							#endif
					#endif
			#endif
	#endif
	
	#define M_CLK	(F_CPU/CLKPR_DIV)
	
	#ifndef BAUD
		#define BAUD (19200UL)
	#endif

	#define TX_PORT	PORTB
	#define TX_DDR	DDRB
	#define TX_PIN	PB1		//PB0

	//#####################################

	#include <avr/io.h>
	#include <stdlib.h>
	#include <stdio.h>
	#include <stdint.h>
	#include <avr/interrupt.h>
	#include <stdbool.h>

	// set the prescaler for the specified baud rate
	#define SUART_PRESCALER_1 ((M_CLK/(BAUD * 1UL)))
	#if SUART_PRESCALER_1 < 0xFF
		#define SUART_TIMER_PRESCALER 1
	#else
		#define SUART_PRESCALER_8 ((M_CLK/(BAUD * 8UL)))
		#if SUART_PRESCALER_8 < 0xFF
			#define SUART_TIMER_PRESCALER 8
		#else
			#define SUART_PRESCALER_64 ((M_CLK/(BAUD * 64UL)))
			#if SUART_PRESCALER_64 < 0xFF
				#define SUART_TIMER_PRESCALER 64
			#else
				#define SUART_PRESCALER_256 ((M_CLK/(BAUD * 256UL)))
				#if SUART_PRESCALER_256 < 0xFF
					#define SUART_SUART_TIMER_PRESCALER 256
				#else
					#define SUART_PRESCALER_1024 ((M_CLK/(BAUD * 1024UL)))
					#if SUART_PRESCALER_1024 < 0xFF
						#define SUART_TIMER_PRESCALER 1024
					#else
						#error "Failed to calculate timer prescaler"
					#endif	/* PRESCALER_1024 */
				#endif		/* PRESCALER_256 */
			#endif			/* PRESCALER_64 */
		#endif				/* PRESCALER_8 */
	#endif					/* PRESCALER_1 */

	#if SUART_TIMER_PRESCALER == 1
		#define SUART_PRESCALER_MASK (_BV(CS00))
	#elif SUART_TIMER_PRESCALER == 8
		#define SUART_PRESCALER_MASK (_BV(CS01))
	#elif SUART_TIMER_PRESCALER == 64
		#define SUART_PRESCALER_MASK (_BV(CS01) | _BV(CS00))
	#elif SUART_TIMER_PRESCALER == 256
		#define SUART_PRESCALER_MASK (_BV(CS02))
	#elif SUART_TIMER_PRESCALER == 1024
		#define SUART_PRESCALER_MASK (_BV(CS02) | _BV(CS00))
	#endif

	#define SUART_COMPARE_PERIOD (M_CLK/(BAUD * SUART_TIMER_PRESCALER))
	//
	//
	// declarations

	void SUART_tx_init();
	void SUART_init_tx_stdio();
	void SUART_send_string(char* string);
	void SUART_send_byte(uint8_t byte);

#endif /* SOFT_UART_H_ */
