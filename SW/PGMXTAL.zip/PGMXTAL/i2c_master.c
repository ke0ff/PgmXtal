/*
 * i2c_master.c
 *
 * Bit-bang I2C.  Uses builtin avr delay to pace the i2c clock
 *
 * Modified by Joe Haas, 11/14/2023
 *
 */ 

#include "i2c_master.h"
#include <util/delay_basic.h>

#define I2C_DLY	5			// adjust this value to slow-down or speed-up the i2c clock.  The si598 max clock rate is 400 Kbps
							// 5 sets i2c_clk to about 133 Kbps
							// 10 sets i2c_clk to about 90 Kbps
							// 20 sets i2c_clk the clock to about 52 Kbps

int i2c_init()
{
	I2C_PORT	= I2C_PORT & ~_BV(SCL);
	I2C_PORT	= I2C_PORT & ~_BV(SDA);

	I2C_DDR		= I2C_DDR & ~_BV(SCL);
	I2C_DDR		= I2C_DDR & ~_BV(SDA);

	if(I2C_PIN_STATE(SCL) == 0)
		return EXIT_FAILURE;
	else if(I2C_PIN_STATE(SDA) == 0)
		return EXIT_FAILURE;

	return EXIT_SUCCESS;
}

void i2c_start()
{
	if(I2C_PIN_STATE(SCL) && !I2C_PIN_STATE(SDA)){
		I2C_SET_PIN_LOW(SCL);
		__builtin_avr_delay_cycles(I2C_DLY);
	}

	I2C_SET_PIN_HIGH(SDA);
	__builtin_avr_delay_cycles(I2C_DLY);
	I2C_SET_PIN_HIGH(SCL);
	__builtin_avr_delay_cycles(I2C_DLY);

	I2C_SET_PIN_LOW(SDA);
	__builtin_avr_delay_cycles(I2C_DLY);
	//I2C_SET_PIN_LOW(SCL);
}

int i2c_send_byte(uint8_t byte)
{
	uint8_t mask = 1<<7;
	while(mask)
	{
		I2C_SET_PIN_LOW(SCL);
		__builtin_avr_delay_cycles(I2C_DLY);

		if(byte & mask)
		{
			I2C_SET_PIN_HIGH(SDA);
			__builtin_avr_delay_cycles(I2C_DLY);
		}
		else
		{
			I2C_SET_PIN_LOW(SDA);
			__builtin_avr_delay_cycles(I2C_DLY);
		}
		I2C_SET_PIN_HIGH(SCL);
		__builtin_avr_delay_cycles(I2C_DLY);

		//loop_until_bit_is_set(I2C_PIN, SCL);

		mask = mask >> 1;
	}

	I2C_SET_PIN_LOW(SCL);
	__builtin_avr_delay_cycles(I2C_DLY);
	I2C_SET_PIN_HZ(SDA);
	__builtin_avr_delay_cycles(I2C_DLY);
	I2C_SET_PIN_HIGH(SCL);
	__builtin_avr_delay_cycles(I2C_DLY);

	if(I2C_PIN_STATE(SDA))
		return NACK;
	else
		return ACK;
}

void i2c_read_byte(uint8_t* byte, bool send_ack)
{
	*byte = 0;
	
	I2C_SET_PIN_LOW(SCL);
	__builtin_avr_delay_cycles(I2C_DLY);
	I2C_SET_PIN_HZ(SDA);
	__builtin_avr_delay_cycles(I2C_DLY);
	uint8_t mask = 1<<7;
	while(mask)
	{
		I2C_SET_PIN_LOW(SCL);
		__builtin_avr_delay_cycles(I2C_DLY);
		I2C_SET_PIN_HIGH(SCL);
		__builtin_avr_delay_cycles(I2C_DLY);
		if(I2C_PIN_STATE(SDA))
			*byte = (*byte) | mask;

		mask = mask >> 1;
	}

	I2C_SET_PIN_LOW(SCL);
	__builtin_avr_delay_cycles(I2C_DLY);
	if(send_ack)
	{
		I2C_SET_PIN_LOW(SDA);
		__builtin_avr_delay_cycles(I2C_DLY);
	}
	I2C_SET_PIN_HIGH(SCL);
	__builtin_avr_delay_cycles(I2C_DLY);
}

void i2c_read_16bit(uint16_t* word, bool send_ack)
{
	uint8_t l_byte = 0;
	uint8_t h_byte = 0;

	i2c_read_byte(&h_byte, true);
	i2c_read_byte(&l_byte, send_ack);

	*word = (uint16_t)h_byte << 8 | l_byte;
}

void i2c_stop()
{
		I2C_SET_PIN_LOW(SCL);
		__builtin_avr_delay_cycles(I2C_DLY);
		I2C_SET_PIN_LOW(SDA);
		__builtin_avr_delay_cycles(I2C_DLY);
		I2C_SET_PIN_HIGH(SCL);
		__builtin_avr_delay_cycles(I2C_DLY);
		I2C_SET_PIN_HIGH(SDA);
		__builtin_avr_delay_cycles(I2C_DLY);
}
