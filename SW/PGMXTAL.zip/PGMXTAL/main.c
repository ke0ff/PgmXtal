/*
 * PGMXTAL.c
 *
 * Created: 10/30/2023 19:30:40
 * Author : KE0FF-Actual
 *
 * This project configures an si598 to operate at one of two frequencies based on the state of PB4.
 * I2C pins SDA (PB0) and SCL (PB2) communicate with the si598.  PB1 is a 2400 baud, N81 serial
 * status output that can be monitored for debug purposes.
 * PB3 connects to the OE of the si598 and is used to mute the output when frequency is changing.
 * PB4 sets one of two channels.
 * The MCU goes into power-down sleep once the si598 is enabled.  PB4 is set as a PCINT to wake the
 * MCU on any change.  The ISR simply clears the interrupt flag. Execution then returns to the
 * sleep function, which returns to the main loop whereby the frequency is set to the new channel.
 * Delays are used to enforce debounce on PB4.  The delay value DBOUNCE can be adjusted at compile-
 * time to meet the needs of a given application.
 *
 */ 

// Un-comment the following line to read the initial register settings for the si598:
//#define DEBUG_READ 1
// If commented, no read takes place and the SW just sets the new frequency

#include <avr/io.h>
#include "chunks.h"
#include "suart.h"
#include "i2c_master.h"

void power_down_forever(void);
uint8_t put_i2c(uint8_t addr, uint8_t data);
void read_si598(void);
void bin2asc(uint8_t b);

#define I2C_ADDR	(0x55 << 1) 
#define OE			PB3
#define CHSEL		PB4
#define DBOUNCE		500


int main(void)
{
	PORTB = PORTB & ~_BV(OE);			// clear OE
	DDRB = DDRB | _BV(OE);
	PORTB = PORTB | _BV(OE);			// set OE
	PORTB = PORTB & ~_BV(OE);			// clear OE
	PORTB = PORTB | _BV(OE);			// set OE
	PORTB = PORTB & ~_BV(OE);			// clear OE

	uint8_t	res;
	uint8_t	i;
	uint8_t* p;
	/////////////////////////////////////////////////////////////////////
	//
	// Fill in data array with reg 7-12 data for upload to si598:

	//				reg addr:   7     8     9    10    11    12
	uint8_t data_array1[] = { 0x60, 0x08, 0x71, 0xa7, 0x81, 0xfe }; // 756 MHz
	uint8_t data_array0[] = { 0xA4, 0x47, 0xC7, 0xCF, 0x60, 0x02 }; // 30.1 MHz


	//
	/////////////////////////////////////////////////////////////////////

	SUART_tx_init();
	SUART_init_tx_stdio();
	DDRB = DDRB & ~_BV(CHSEL);			// set chsel = input
	PCMSK = (1<<PCINT4);				// enable CHSEL to wake from sleep
	GIMSK = (1<<PCIE); 

	
	sei();
	while(1)
	{
		if(i2c_init() == EXIT_SUCCESS)
		{
#ifdef DEBUG_READ
			read_si598();
#endif
			if(PINB & _BV(CHSEL)){
				p = data_array1;
				printf("1\n");
			}else{
				p = data_array0;
				printf("0\n");
			}
			res = put_i2c(137, 0x10);
			for(i=7; i<13; i++){
			res |= put_i2c(i, p[i-7]);
				
			}
			res |= put_i2c(137, 0x08);
			res |= put_i2c(135, 0x40);

			printf("%s\n", (res == ACK)? "OK": "FAIL");


		}else{
			printf("i2c fail\n");

		}
		_delay_loop_2(DBOUNCE);
		PORTB = PORTB | _BV(OE);			// set OE
		power_down_forever();
		PORTB = PORTB & ~_BV(OE);			// clear OE
		_delay_loop_2(DBOUNCE);
	}

	return EXIT_SUCCESS;
}

uint8_t put_i2c(uint8_t addr, uint8_t data){
	uint8_t rtn;

	i2c_start();
	rtn = i2c_send_byte(I2C_ADDR | I2C_ADDR_WRITE_FLAG);
	rtn |= i2c_send_byte(addr);	//reg
	rtn |= i2c_send_byte(data);	//reg
	i2c_stop();
	return rtn;
}


void power_down_forever(void)
{

	MCUCR &= ~(1<<SM0);							// enabling sleep mode and powerdown sleep mode
	MCUCR |= (1<<SM1);							// enabling sleep mode and powerdown sleep mode
	MCUCR |= (1<<SE);							// Enabling sleep enable bit
	__asm__ __volatile__("sleep" "\n\t" ::);	// Power down cpu
}

ISR (PCINT0_vect)								// Interrupt service routine
{
	GIFR = (1<<PCIF);							// clear the flags register
}


#ifdef DEBUG_READ
void read_si598(void){
	uint8_t		i;
	uint8_t		res = 0;
	uint8_t		buf[6];
	uint8_t*	p;

	for(i=0, p=buf; i<6; i++){
		i2c_start();
		res |= i2c_send_byte(I2C_ADDR | I2C_ADDR_WRITE_FLAG);
		res |= i2c_send_byte(7+i);
		i2c_start();
		res |= i2c_send_byte(I2C_ADDR | I2C_ADDR_READ_FLAG);
		i2c_read_byte(p++, 0);
		i2c_stop();
		_delay_loop_2(100);
	}
	printf("%s\n", (res == ACK)? "rOK": "rFAIL");
	printf("read ");
	for(i=0; i<6; i++){
		bin2asc(buf[i]);
	}
	printf("/n");
}

void bin2asc(uint8_t b){
	char c;
	char d;

	c = (char)(b>>4) + '0';
	if(c>'9') c+= 'A'-'9' - 1;
	d = (char)(b&0xf) + '0';
	if(d>'9') d+= 'A'-'9' - 1;
	printf("%c%c ",c,d);
}
#endif
// end main.c