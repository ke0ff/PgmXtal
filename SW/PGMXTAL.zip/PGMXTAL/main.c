/*
 * PGMXTAL.c
 *
 * Created: 10/30/2023 19:30:40
 * Author : KE0FF-Actual
 *
 * This project configures an si598 to operate at one of two frequencies based on the state of PB4.
 * I2C pins SDA (PB0) and SCL (PB2) communicate with the si598.  PB1 is a 4800 baud, N81 serial
 * status output that can be monitored for debug purposes.
 * PB3 connects to the OE of the si598 and is used to mute the output when frequency is changing.
 * PB4 sets one of two channels.
 * The MCU goes into power-down sleep once the si598 is enabled.  PB4 is set as a PCINT to wake the
 * MCU on any change.  The ISR simply clears the interrupt flag. Execution then returns to the
 * sleep function, which returns to the main loop whereby the frequency is set to the new channel.
 * Delays are used to enforce debounce on PB4.  The delay value DBOUNCE can be adjusted at compile-
 * time to meet the needs of a given application.
 *
 */ 

// Version 1.1, 11-14-23
//		* SOUT baud rate debug.  Trying to get timer defines correct, but they are off by a factor of 8.
//			- chip is fused at the factory to divide sysclk by 8 to drive clkio
//			- setup suart.h to allow flexible clock selection.
//			- baud rate is currently 19200
//		* Moved reset banner to after initial PGM operation, then it is disabled until next POR.
//		* Added CLKPR to init code.  Allows faster UART speeds
//		* Added bit delays to I2C code to allow the bit rate to be throttled.  Currently at about 133 Kbps
//		* CHSEL and "OK" msgs only display if ipl == 1 (so they only display once)
//
// Version 1.0, 11-12-23
//		* released baseline code


// Un-comment the following line to read the initial register settings for the si598 (values sent out the UART port):
//#define DEBUG_READ 1
// If commented, no read takes place and the SW just sets the new frequency

#include <avr/io.h>
#include "chunks.h"
#include "suart.h"
#include "i2c_master.h"

// local function declarations

void power_down_forever(void);
uint8_t put_i2c(uint8_t addr, uint8_t data);
void read_si598(void);
void bin2asc(uint8_t b);

// local defines

#define I2C_ADDR	(0x55 << 1)		// si598 i2c address (shifted to make room for r/w bit)
#define OE			PB3				// OE port pin
#define CHSEL		PB4				// CHSEL port pin
#define OE_DLY		500				// OE delay (PLL freq stable): adjust this value if faster or slower OE delay times are needed.
#define DBOUNCE		500				// CHSEL debounce delay: adjust this value if faster or slower switching times are needed.


////////////////////////////////////////////////////
// main() operates main-loop of control function
////////////////////////////////////////////////////

int main(void)
{
	uint8_t	ipl = 1;							// set power-on flag

	CLKPR = _BV(CLKPCE);						// update sys-clock prescale
	CLKPR = (CLKPR_BIT);

	PORTB = PORTB & ~_BV(OE);					// clear OE & set for output
	DDRB = DDRB | _BV(OE);

	uint8_t	res;
	uint8_t	i;
	uint8_t* p;
	/////////////////////////////////////////////////////////////////////
	//
	// Fill in data array with reg 7-12 data for upload to si598:
	//				reg addr:   7     8     9    10    11    12
	uint8_t data_array1[] = { 0x60, 0x08, 0x71, 0xa7, 0x81, 0xfe }; // 756 MHz
	uint8_t data_array0[] = { 0xA4, 0x47, 0xC7, 0xCF, 0x60, 0x02 }; // 30.1 MHz

	//
	/////////////////////////////////////////////////////////////////////

	SUART_tx_init();							// init status UART
	SUART_init_tx_stdio();
	DDRB = DDRB & ~_BV(CHSEL);					// set chsel = input
	PCMSK = (1<<PCINT4);						// configure CHSEL to wake from sleep
	GIMSK = (1<<PCIE); 
	sei();
	while(1)
	{
		if(i2c_init() == EXIT_SUCCESS)			// init i2c
		{
#ifdef DEBUG_READ
			read_si598();						// if read debug compile switch enabled, read the registers and send them to the UART
#endif
			if(PINB & _BV(CHSEL)){				// capture CHSEL and set pointer to corresponding array
				p = data_array1;
				if(ipl){
					printf("1\n");
				}
			}else{
				p = data_array0;
				if(ipl){
					printf("0\n");
				}
			}
			res = put_i2c(137, 0x10);			// unfreeze DPLL
			for(i=7; i<13; i++){				// send data
			res |= put_i2c(i, p[i-7]);
				
			}
			res |= put_i2c(137, 0x08);			// refreeze DPLL
			res |= put_i2c(135, 0x40);

			if(ipl){
				printf("%s\n", (res == ACK)? "OK": "FAIL");	// report status
			}
		}else{
			printf("i2c fail\n");
		}
		_delay_loop_2(OE_DLY);					// delay to allow DPLL to stabilize
		PORTB = PORTB | _BV(OE);				// set OE
		if(ipl){
			printf("www.github.com/ke0ff/PgmXtal\n");	// IPL banner msg - send only once
			printf("V1.1 11/2023 (c)ke0ff, a.r.r.\n");
			ipl = 0;							// clear power-on flag
		}
		power_down_forever();					// power-down (waits for CHSEL to change then the code continues...)
		PORTB = PORTB & ~_BV(OE);				// clear OE
		_delay_loop_2(DBOUNCE);					// debounce wait, then re-loop to top of while()...
	}

	return EXIT_SUCCESS;						// should never get here (fault-tolerant exit)
}

////////////////////////////////////////////////////
// put_i2c() sents data to reg addr
////////////////////////////////////////////////////

uint8_t put_i2c(uint8_t addr, uint8_t data){
	uint8_t rtn;

	i2c_start();												// i2c start
	rtn = i2c_send_byte(I2C_ADDR | I2C_ADDR_WRITE_FLAG);		// i2c addr
	rtn |= i2c_send_byte(addr);									// register addr
	rtn |= i2c_send_byte(data);									// register data
	i2c_stop();													// i2c stop
	return rtn;													// i2c status return
}

////////////////////////////////////////////////////
// power_down_forever() enters power-down sleep
////////////////////////////////////////////////////

void power_down_forever(void)
{

	MCUCR &= ~(1<<SM0);							// enabling sleep mode and powerdown sleep mode
	MCUCR |= (1<<SM1);
	MCUCR |= (1<<SE);							// Enabling sleep enable bit
	// Power down cpu (inline assem)
	__asm__ __volatile__("sleep" "\n\t" ::);
}

////////////////////////////////////////////////////
// PCINT ISR() clears the PCINT flag when CHSEL changes
////////////////////////////////////////////////////

ISR (PCINT0_vect)								// Interrupt service routine
{
	GIFR = (1<<PCIF);							// clear the flags register
}

#ifdef DEBUG_READ

////////////////////////////////////////////////////
// read_si598() reads registers 7-12 of the si598
//	and reports them to the UART
////////////////////////////////////////////////////

void read_si598(void){
	uint8_t		i;
	uint8_t		res = 0;
	uint8_t		buf[6];
	uint8_t*	p;

	for(i=0, p=buf; i<6; i++){									// read 6 registers
		i2c_start();											// set i2c start condition
		res |= i2c_send_byte(I2C_ADDR | I2C_ADDR_WRITE_FLAG);	// send i2c addr
		res |= i2c_send_byte(7+i);								// send register addr
		i2c_start();											// repeated start
		res |= i2c_send_byte(I2C_ADDR | I2C_ADDR_READ_FLAG);	// send i2c addr
		i2c_read_byte(p++, 0);									// read register
		i2c_stop();												// i2c stop
	}
	printf("%s\n", (res == ACK)? "rOK": "rFAIL");				// report i2c status
	printf("read ");											// list out the registers
	for(i=0; i<6; i++){
		bin2asc(buf[i]);
	}
	printf("/n");												// EOL
}

////////////////////////////////////////////////////
// bin2asc() sents ascii hex representation (2 characters)
//	of the given byte to the UART
////////////////////////////////////////////////////

void bin2asc(uint8_t b){
	char c;
	char d;

	c = (char)(b>>4) + '0';						// convert upper nybble to ASCII
	if(c>'9') c+= 'A'-'9' - 1;
	d = (char)(b&0xf) + '0';					// convert lower nybble ti ASCII
	if(d>'9') d+= 'A'-'9' - 1;
	printf("%c%c ",c,d);						// send to UART
}
#endif

// end main.c