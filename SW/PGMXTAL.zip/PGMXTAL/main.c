/*
 * PGMXTAL.c
 *
 * Created: 10/30/2023 19:30:40
 * Author : KE0FF-Actual
 */ 

#include <avr/io.h>
#include "chunks.h"
#include "suart.h"
#include "i2c_master.h"

void power_down_forever(void);
uint8_t put_i2c(uint8_t addr, uint8_t data);

#define I2C_ADDR	(0b10101010) 
#define OE			PB3
#define CHSEL		PB4


int main(void)
{
	uint8_t	res;
	uint8_t	i;
	uint8_t* p;
	/////////////////////////////////////////////////////////////////////
	//
	// Fill in data array with reg 7-12 data for upload to si598:

	//				reg addr:   7     8     9    10    11    12
	uint8_t data_array1[] = { 0x60, 0x08, 0x71, 0xa7, 0x81, 0xfe }; // 756 MHz
	uint8_t data_array0[] = { 0xA4, 0x47, 0xC7, 0xCF, 0x60, 0x02 }; // 30.1 MHz


	//
	/////////////////////////////////////////////////////////////////////

	SUART_tx_init();
	SUART_init_tx_stdio();
	PORTB = PORTB & ~_BV(OE);			// clear OE
	DDRB = DDRB | _BV(OE);
	DDRB = DDRB & ~_BV(CHSEL);			// set chsel = input
	sei();
	while(1)
	{
		if(i2c_init() == EXIT_SUCCESS)
		{
			if(PINB & _BV(CHSEL)){
				p = data_array1;
				printf("1\n");
			}else{
				p = data_array0;
				printf("0\n");
			}
			res = put_i2c(137, 0x10);
			for(i=7; i<13; i++){
			res |= put_i2c(i, p[i-7]);
				
			}
			res |= put_i2c(137, 0x08);
			res |= put_i2c(135, 0x40);

			printf("%s\n", (res == ASK)? "OK": "FAIL");


		}else{
			printf("i2c fail\n");

		}
		_delay_loop_2(500);
		PORTB = PORTB | _BV(OE);			// set OE
		power_down_forever();
	}

	return EXIT_SUCCESS;
}

uint8_t put_i2c(uint8_t addr, uint8_t data){
	uint8_t rtn;

	i2c_start();
	rtn = i2c_send_byte(I2C_ADDR | I2C_ADDR_WRITE_FLAG);
	rtn |= i2c_send_byte(addr);	//reg
	rtn |= i2c_send_byte(data);	//reg
	i2c_stop();
	return rtn;
}


void power_down_forever(void)
{

	MCUCR|= (1<<SM1);							// enabling sleep mode and powerdown sleep mode
	MCUCR|= (1<<SE);							// Enabling sleep enable bit
	__asm__ __volatile__("sleep" "\n\t" ::);	// Power down cpu
}
