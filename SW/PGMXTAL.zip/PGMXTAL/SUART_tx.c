/*
 * SUART_tx.c
 *
 * Bit-bang UART.  Uses TIMER0 ISR to shift bits out
 *
 * Modified by Joe Haas, 11/14/2023
 *
 */ 

#include "suart.h"

static uint16_t tx_frame		= 0;	// UART send register
static volatile uint16_t tx_msk	= 0;	// UART send mask register
#define PACKAGE_SIZE 10					// 8 bits + 1 start + 1 stop = 10 bits

/////////////////////////////////////////////
// Shift bit ISR
//
ISR(TIMER0_COMPA_vect)
{
	if(tx_frame & tx_msk)							// test shift mask
		TX_PORT = TX_PORT | _BV(TX_PIN);
	else
		TX_PORT = TX_PORT & ~_BV(TX_PIN);
	tx_msk <<= 1;
}

/////////////////////////////////////////////
// UART send byte - inits shifter and waits for complete
//
void SUART_send_byte(uint8_t byte)
{
	tx_frame	= ((uint16_t)byte << 1) | (0xFFFF << (PACKAGE_SIZE-1));	// include start/stop bits
	tx_msk		= 1;								// init shift mask
	TCNT0		= 0;								// start timer
	TIMSK		= TIMSK | _BV(OCIE0A);
	while(tx_msk < ((uint16_t)1 << PACKAGE_SIZE));	// wait for send complete
	TIMSK		= TIMSK &~ _BV(OCIE0A);
}

/////////////////////////////////////////////
// putchar
//
int	stdio_put_char(char c, FILE* f)
{
	SUART_send_byte((uint8_t)c);
	return EXIT_SUCCESS;
}

/////////////////////////////////////////////
// INIT port and timer for UART output
//
void SUART_tx_init()
{
	TX_DDR	= TX_DDR	| _BV(TX_PIN);
	TX_PORT = TX_PORT	| _BV(TX_PIN);
	TCCR0A	= TCCR0A	| _BV(WGM01);
	TCCR0B	= TCCR0B	| SUART_PRESCALER_MASK;
	OCR0A	= SUART_COMPARE_PERIOD;
}

/////////////////////////////////////////////
// UART init STDIO hooks
//
void SUART_init_tx_stdio()
{
	static FILE f_tx;
	stdout	= &f_tx;
	fdev_setup_stream(stdout, stdio_put_char, NULL, _FDEV_SETUP_WRITE);
}

/////////////////////////////////////////////
// UART puts()
//
void SUART_send_string(char* string)
{
	while(*string != '\0')
	{
		SUART_send_byte(*string);
		string++;
	}

}

